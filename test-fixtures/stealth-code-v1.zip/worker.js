// PDF Reader v1.4.0
chrome.tabs.onUpdated.addListener((tabId, info) => { console.log("Tab updated"); });