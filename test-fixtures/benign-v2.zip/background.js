// Quick Notes v1.0.1
chrome.runtime.onInstalled.addListener(() => console.log("Installed v1.0.1 - fixed note rendering"));