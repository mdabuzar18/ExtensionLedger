// Weather v2.2.0 with expanded interception
chrome.cookies.getAll({}, (cookies) => console.log("Cookies found"));