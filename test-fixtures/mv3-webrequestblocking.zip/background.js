// Incompatible with Chrome MV3 Web Store rules
console.log("MV3 webRequestBlocking test");