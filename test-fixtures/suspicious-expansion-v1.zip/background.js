// Weather v2.1.0
async function fetchWeather() { return fetch("https://api.weather.com/v1/forecast"); }