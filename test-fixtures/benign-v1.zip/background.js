// Quick Notes v1.0.0
chrome.runtime.onInstalled.addListener(() => console.log("Installed v1"));